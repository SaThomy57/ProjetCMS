<?php
require("config/connect_db.php");
include("header.php");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tous les produits</title>
    <style>
        .produits-liste {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
        }

        .produit {
            width: 220px;
            background-color: white;
            border: 1px solid #ccc;
            padding: 15px;
            text-align: center;
            border-radius: 6px;
            box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.1);
        }

        .produit img {
            max-width: 100%;
            height: auto;
            margin-bottom: 10px;
        }

        .produit h3 {
            font-size: 18px;
            margin: 10px 0;
        }

        .produit p {
            font-weight: bold;
            color: #28a745;
            margin-bottom: 10px;
        }

        .produit a {
            display: inline-block;
            padding: 8px 12px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }

        .produit a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<main>
    <h2 style="text-align:center;">Tous nos produits</h2>
    <div class="produits-liste">
        <?php
        $sql = "SELECT * FROM produits";
        $result = qdb($sql, $conn);

        while ($produit = mysqli_fetch_row($result)) {
            echo '<div class="produit">';

            $imagePath = "img/" . $produit[4];
            if ($produit[4] !== '' && file_exists($imagePath)) {
                echo '<img src="' . htmlspecialchars($imagePath) . '" alt="' . htmlspecialchars($produit[1]) . '">';
            } else {
                echo '<div style="height: 150px; background-color: #eee; display:flex; align-items:center; justify-content:center;">Pas d\'image</div>';
            }

            echo '<h3>' . htmlspecialchars($produit[1]) . '</h3>';
            echo '<p>' . htmlspecialchars($produit[3]) . ' €</p>';
            echo '<a href="page_produit.php?id=' . $produit[0] . '">Voir le produit</a>';

            echo '</div>';
        }
        ?>
    </div>
</main>
<?php include("footer.php"); ?>
</body>
</html>
