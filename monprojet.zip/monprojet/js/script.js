document.addEventListener("DOMContentLoaded", function() {
    const liensSupprimer = document.querySelectorAll("a.supprimer");
  
    liensSupprimer.forEach(function(lien) {
      lien.addEventListener("click", function(event) {
        const confirmation = confirm("Voulez-vous vraiment supprimer ce produit ?");
  
        if (!confirmation) {
          event.preventDefault();
        }
      });
    });
  });
  