<?php
session_start();
require_once("config/connect_db.php");
include("header.php");

// Récupération des données via GET
$email = isset($_GET['email']) ? htmlspecialchars($_GET['email']) : '';
$mdp = isset($_GET['mdp']) ? htmlspecialchars($_GET['mdp']) : '';

if ($email != '' && $mdp!= '') {
    // Échappement SQL
    $email = mysqli_real_escape_string($conn, $email);
    $mdp = mysqli_real_escape_string($conn, $mdp);

    // Requête SQL directe avec email et mot de passe en clair
    $sql = "SELECT * FROM utilisateurs WHERE email = '$email' AND mot_de_passe = '$mdp'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['id_utilisateur'] = $user['id_utilisateur'];
        $_SESSION['nom'] = $user['nom'];
        echo "<p style='color:green;'>Connexion réussie. Bonjour " . htmlspecialchars($user['prenom']) . " !</p>";
        echo '<a href="accueil.php">→ Aller à l\'accueil</a>';
    } else {
        echo "<p style='color:red;'>Identifiants incorrects.</p>";
    }
} else {
    echo "<p style='color:red;'>Veuillez remplir tous les champs.</p>";
}

include("footer.php");
?>

