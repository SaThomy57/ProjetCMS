<?php
include("header.php");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Boutique ecom</title>
</head>
<body>
    <h1>Ajouter un Produit</h1>
    <form action="sauver.php" method="GET">
        <label>Nom :</label><br>
        <input type="text" name="nom" required><br><br>
        <label>Description :</label><br>
        <textarea name="description" required></textarea><br><br>
        <label>Prix (€) :</label><br>
        <input type="number" step="0.01" name="prix" required><br><br>
        <label>Image :</label><br>
        <input type="file" name="image" accept="img/*" required><br><br>
        <button type="submit" name="ajouter">Ajouter</button>
    </form>
    <?php include("footer.php"); ?>
</body>
</html>