<?php
// Définition des informations de connexion à la base de données
$dbhost = "localhost"; // Adresse du serveur MySQL (localhost pour un serveur local)
$dbuser = "root"; // Nom d'utilisateur MySQL (par défaut "root" pour WAMP)
$dbpassword = ""; // Mot de passe MySQL (vide par défaut pour WAMP)
$dbname = "Projet"; // Nom de la base de données à utiliser

// Connexion au serveur MySQL avec mysqli
$conn = new mysqli($dbhost, $dbuser, $dbpassword, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

// Définition d'une fonction pour exécuter des requêtes SQL
function qdb($sql, $conn)
{
    // Exécution de la requête SQL
    $resultat = $conn->query($sql);

    // Gestion des erreurs
    if (!$resultat) {
        echo "Erreur MySQL : " . $conn->error . "<br>";
        echo "Requête MySQL : " . $sql . "<br>";
        die; // Arrête l'exécution du script
    }

    // Retourne le résultat de la requête si aucune erreur ne survient
    return $resultat;
}
?>