</main>
<footer style="background-color:#333; color:white; text-align:center; padding:15px; margin-top:50px;">
    &copy; <?php echo date("Y"); ?> - Ma Boutique. Tous droits réservés.
</footer>
</body>
</html>
