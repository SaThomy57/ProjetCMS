<?php
include('header.php');
?>

<h1>Connexion</h1>
<form action="verif_connexion.php" method="GET">
    <label>Email :</label><br>
    <input type="email" name="email" required><br><br>

    <label>Mot de passe :</label><br>
    <input type="text" name="mdp" required><br><br>

    <button type="submit">Se connecter</button>
</form>

<?php
include('footer.php');
?>
