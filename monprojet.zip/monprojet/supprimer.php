<?php
require_once("config/connect_db.php"); // Connexion à la base
include("header.php"); // Inclusion de l'en-tête

// Récupération de l'ID du produit à supprimer
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Vérification simple
if ($id > 0) {
    $sql = "DELETE FROM produits WHERE id = $id";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<p style='color:green;'>Produit supprimé avec succès.</p>";
    } else {
        echo "<p style='color:red;'>Erreur MySQL : " . mysqli_error($conn) . "</p>";
    }
} else {
    echo "<p style='color:red;'>ID invalide.</p>";
}

echo "<p><a href='liste_produit.php'>← Retour à la liste des produits</a></p>";
include("footer.php"); // Inclusion du pied de page
?>
