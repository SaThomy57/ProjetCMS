<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon Site E-commerce</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        header {
            background-color: #333;
            color: white;
            padding: 20px;
            text-align: center;
        }

        nav {
            background-color: #444;
            display: flex;
            justify-content: center;
            gap: 20px;
            padding: 12px;
            flex-wrap: wrap;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 8px 12px;
            transition: background 0.3s ease;
            border-radius: 4px;
        }

        nav a:hover {
            background-color: #666;
        }

        nav .right {
            margin-left: auto;
        }

        main {
            padding: 30px;
            background-color: #f4f4f4;
            min-height: 80vh;
        }
    </style>
</head>
<body>

<header>
    <h1>Ma Boutique en Ligne</h1>
    <p>Produits de qualité au meilleur prix</p>
</header>

<nav>
    <a href="accueil.php">Accueil</a>
    <a href="tout_produit.php">Tous nos produits</a>

    <?php
if (isset($_SESSION['id_utilisateur'])) {
    echo '<a href="espace_membre.php">Espace Membre</a>';
    echo '<a href="deconnexion.php">Déconnexion</a>';
} else {
    echo '<a href="connexion.php">Connexion</a>';
    echo '<a href="inscription.php">Inscription</a>';
}
?>
</nav>

<main>
