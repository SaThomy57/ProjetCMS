<?php
require_once("config/connect_db.php"); // Connexion à la base
include("header.php"); // Inclusion de l'en-tête

// Vérifie si un ID de produit est passé
if (!isset($_GET['id'])) {
    echo "<p style='color:red;'>Produit introuvable.</p>";
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;


// Requête pour récupérer le produit depuis la base
$sql = "SELECT * FROM produits WHERE id = $id";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) === 0) {
    echo "<p style='color:red;'>Ce produit n'existe pas.</p>";
    exit;
}

$produit = mysqli_fetch_row($result);
?>

<style>
.produit-container {
    max-width: 800px;
    margin: 40px auto;
    padding: 20px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
    text-align: center;
}
.produit-container img {
    max-width: 300px;
    height: auto;
    margin-bottom: 20px;
}
.produit-container h2 {
    margin-bottom: 10px;
}
.produit-container .prix {
    font-size: 20px;
    font-weight: bold;
    color: #28a745;
}
.produit-container .description {
    margin: 20px 0;
    white-space: pre-line;
}
.produit-container .btn {
    display: inline-block;
    margin: 10px;
    padding: 12px 20px;
    background-color: #007bff;
    color: white;
    text-decoration: none;
    border-radius: 5px;
}
.produit-container .btn:hover {
    background-color: #0056b3;
}
</style>

<div class="produit-container">
    <h2><?php echo htmlspecialchars($produit[1]); ?></h2>

    <?php
    $imagePath = "img/" . $produit[4];
    if (isset($produit[4]) && $produit[4] !== '' && file_exists($imagePath)) {
        echo '<img src="' . htmlspecialchars($imagePath) . '" alt="' . htmlspecialchars($produit[1]) . '">';
    } else {
        echo '<div style="height: 200px; background-color: #eee; display: flex; align-items: center; justify-content: center;">
                <span>Pas d\'image</span>
              </div>';
    }
    ?>

    <p class="prix"><?php echo sprintf("%.2f", $produit[3]); ?> €</p>
    <p class="description"><?php echo htmlspecialchars($produit[2]); ?></p>

    <a href="accueil.php" class="btn">← Retour à l'accueil</a>
    <a href="#" class="btn" onclick="alert('Fonction panier à venir !')">🛒 Ajouter au panier</a>
</div>

<?php include("footer.php"); // Inclusion du pied de page ?>
