<?php
session_start();
require_once("config/connect_db.php");
include("header.php");

$id = intval($_SESSION['id_utilisateur']);

$sql = "SELECT nom, prenom, email FROM utilisateurs WHERE id_utilisateur = $id";
$result = mysqli_query($conn, $sql);

$user = mysqli_fetch_row($result); // Retourne un tableau indexé : [0 => nom, 1 => prenom, 2 => email]

if (!$user) {
    echo "<p style='color:red;'>Erreur : utilisateur introuvable.</p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace Membre</title>
    <style>
        .container {
            background-color: white;
            max-width: 600px;
            margin: auto;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .info {
            margin-top: 20px;
        }
        .info p {
            font-size: 18px;
            margin: 10px 0;
        }
        .logout {
            display: block;
            margin-top: 30px;
            text-align: center;
        }
        .logout a {
            text-decoration: none;
            background-color: #dc3545;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
        }
        .logout a:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bienvenue dans votre espace, <?php echo htmlspecialchars($user[1]); ?> !</h1> <!-- prénom -->
        <div class="info">
            <p><strong>Nom :</strong> <?php echo htmlspecialchars($user[0]); ?></p>         <!-- nom -->
            <p><strong>Prénom :</strong> <?php echo htmlspecialchars($user[1]); ?></p>       <!-- prénom -->
            <p><strong>Email :</strong> <?php echo htmlspecialchars($user[2]); ?></p>        <!-- email -->
        </div>
        <div class="logout">
            <a href="deconnexion.php">Se déconnecter</a>
        </div>
    </div>
    <?php include("footer.php"); ?>
</body>
</html>
