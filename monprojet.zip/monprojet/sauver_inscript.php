<?php
require_once("config/connect_db.php"); // Connexion à la base
include("header.php"); // Inclusion de l'en-tête

// Récupération des données
$nom = isset($_GET['nom']) ? htmlspecialchars($_GET['nom']) : '';
$prenom = isset($_GET['prenom']) ? htmlspecialchars($_GET['prenom']) : '';
$email = isset($_GET['email']) ? htmlspecialchars($_GET['email']) : '';
$mdp = isset($_GET['mdp']) ? htmlspecialchars($_GET['mdp']) : '';

// Affichage (pour test)
echo "<h1>Contenu de l'inscription </h1>";
echo "<p><strong>Nom :</strong> $nom</p>";
echo "<p><strong>prenom :</strong> $prenom</p>";
echo "<p><strong>email :</strong> $email </p>";
echo "<p><strong>mot de passe :</strong> $mdp</p>";

// Vérification manuelle
if (isset($nom) && $nom != '' &&
    isset($prenom) && $prenom != '' &&
    isset($email) && $email != '' &&
    isset($mdp) && $mdp != '') {

    $sql = "INSERT INTO utilisateurs (nom, prenom, email, mot_de_passe)
            VALUES ('$nom', '$prenom', '$email', '$mdp')";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<p style='color:green;'>Vous êtes bien inscrit(e)</p>";
    } else {
        echo "<p style='color:red;'>Erreur MySQL : " . $conn->error . "</p>";
    }

} else {
    echo "<p style='color:red;'>Erreur : tous les champs doivent être remplis.</p>";
}
include("footer.php"); // Inclusion du pied de page
?>