<?php
require_once("config/connect_db.php"); // Connexion à la base
include("header.php"); // Inclusion de l'en-tête

// Requête pour récupérer tous les utilisateurs
$sql = "SELECT * FROM utilisateurs";
$resultat = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Utilisateurs</title>
    <style>
        table {
            border-collapse: collapse;
            width: 90%;
            margin: 30px auto;
            background-color: #f9f9f9;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #eee;
        }
        a {
            text-decoration: none;
            color: blue;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <h1 style="text-align:center;">Liste des Utilisateurs</h1>

    <table>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
        </tr>

        <?php
        while ($user = mysqli_fetch_row($resultat)) {
            echo "<tr>";
            echo "<td>" . $user[0] . "</td>";
            echo "<td>" . htmlspecialchars($user[1]) . "</td>";
            echo "<td>" . htmlspecialchars($user[2]) . "</td>";
            echo "<td>" . htmlspecialchars($user[3]) . "</td>";
        }
        ?>
    </table>
    <?php include("footer.php"); // Inclusion du pied de page ?>
</body>
</html>
