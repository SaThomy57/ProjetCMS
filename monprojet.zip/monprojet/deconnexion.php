<?php
session_start(); // Démarre la session si ce n'est pas déjà fait
include("header.php"); // Inclusion de l'en-tête

// Détruit toutes les données de la session
if(session_destroy()){
    // Redirige vers la page de connexion
    echo "<h1>Déconnexion réussie</h1>";
    echo "<p style='color:green;'>Vous avez été déconnecté avec succès.</p>";
    echo '<a href="connexion.php">→ Retour à la connexion</a>';
} else {
    echo "<p style='color:red;'>Erreur lors de la déconnexion.</p>";
}

include("footer.php"); // Inclusion du pied de page
?>
