<?php
require_once("config/connect_db.php"); // Connexion à la base
include("header.php"); // Inclusion de l'en-tête

// Récupération des données
$nom = isset($_GET['nom']) ? htmlspecialchars($_GET['nom']) : '';
$desc = isset($_GET['description']) ? htmlspecialchars($_GET['description']) : '';
$prix = isset($_GET['prix']) ? htmlspecialchars($_GET['prix']) : '';
$image = isset($_GET['image']) ? htmlspecialchars($_GET['image']) : '';

// Affichage (pour test)
echo "<h1>Contenu du formulaire</h1>";
echo "<p><strong>Nom :</strong> $nom</p>";
echo "<p><strong>Description :</strong> $desc</p>";
echo "<p><strong>Prix :</strong> $prix €</p>";
echo "<p><strong>Image :</strong> $image</p>";

// Vérification manuelle sans empty()
if (isset($nom) && $nom != '' &&
    isset($desc) && $desc != '' &&
    isset($prix) && $prix != '' &&
    isset($image) && $image != '') {

    $sql = "INSERT INTO produits (nom, description, prix, image)
            VALUES ('$nom', '$desc', '$prix', '$image')";

    $result = $conn->query($sql);

    if ($result) {
        echo "<p style='color:green;'>Produit ajouté avec succès !</p>";
    } else {
        echo "<p style='color:red;'>Erreur MySQL : " . $conn->error . "</p>";
    }

} else {
    echo "<p style='color:red;'>Erreur : tous les champs doivent être remplis.</p>";
}
include("footer.php"); // Inclusion du pied de page
?>
