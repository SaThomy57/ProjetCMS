<?php
require_once("config/connect_db.php"); // Connexion à la base
include("header.php"); // Inclusion de l'en-tête

// Récupération de l'identifiant du produit à modifier
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Si l'utilisateur a cliqué sur le bouton "Modifier"
if (isset($_GET['modifier'])) {

    // Récupération des champs du formulaire
    $nom = htmlspecialchars($_GET['nom']);
    $desc = htmlspecialchars($_GET['description']);
    $prix = htmlspecialchars($_GET['prix']);
    $image = htmlspecialchars($_GET['image']);

    // Vérifie que tous les champs sont remplis
    if ($nom != '' && $desc != '' && $prix != '' && $image != '') {
        $sql = "UPDATE produits SET nom = '$nom', description = '$desc', prix = '$prix', image = '$image' WHERE id = $id";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            echo "<p style='color:green;'>Produit modifié avec succès !</p>";
            echo "<p><a href='liste_produit.php'>← Retour à la liste</a></p>";
        } else {
            echo "<p style='color:red;'>Erreur MySQL : " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p style='color:red;'>Tous les champs doivent être remplis.</p>";
    }
}

// Si on n'a pas encore modifié, on affiche le formulaire
else {
    // Récupérer les données du produit
    $sql = "SELECT * FROM produits WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $produit = mysqli_fetch_row($result);

    if (!$produit) {
        echo "<p>Produit introuvable.</p>";
        exit;
    }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un produit</title>
</head>
<body>
    <h1>Modifier le Produit</h1>
    <form method="GET" action="modifier.php">
        <!-- Champ caché pour garder l'ID -->
        <input type="hidden" name="id" value="<?php echo $produit[0]; ?>">

        <label>Nom :</label><br>
        <input type="text" name="nom" value="<?php echo htmlspecialchars($produit[1]); ?>"><br><br>

        <label>Description :</label><br>
        <textarea name="description"><?php echo htmlspecialchars($produit[2]); ?></textarea><br><br>

        <label>Prix (€) :</label><br>
        <input type="number" name="prix" step="0.01" value="<?php echo htmlspecialchars($produit[3]); ?>"><br><br>

        <label>Image :</label><br>
        <input type="text" name="image" value="<?php echo htmlspecialchars($produit[4]); ?>"><br><br>

        <button type="submit" name="modifier">Modifier</button>
    </form>
    <?php include("footer.php"); // Inclusion du pied de page ?>
</body>
</html>

<?php } // fin du else ?>
