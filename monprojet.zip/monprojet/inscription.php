<?php 
    include('header.php'); 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Boutique ecom</title>
</head>
<body>
    <h1>Inscription</h1>
    <form action="sauver_inscript.php" method="GET">
        <label>Nom :</label><br>
        <input type="text" name="nom" required><br><br>
        <label>Prénom :</label><br>
        <input type="text" name="prenom" required><br><br>
        <label>Email :</label><br>
        <input type="email" name="email" required><br><br>
        <label>Mot de passe :</label><br>
        <input type="password" name="mdp" required><br><br>
        <button type="submit" name="ajouter">S'inscrire</button>
    </form>
    <?php include("footer.php"); ?>
</body>
</html>