<?php
require_once("config/connect_db.php");
include("header.php");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil - Mon E-commerce</title>
    <style>
        .produits-moment {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
        }
        .produit {
            border: 1px solid #ccc;
            background-color: white;
            padding: 15px;
            width: 200px;
            text-align: center;
        }
        .produit img {
            max-width: 100%;
            height: auto;
        }
        .button {
            background-color: #28a745;
            color: white;
            padding: 12px 20px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <main>
        <h2 style="text-align:center;">Nos produits du moment</h2>
        <div class="produits-moment">
            <?php
            $sql = "SELECT * FROM produits ORDER BY id DESC LIMIT 4";
            $result = qdb($sql, $conn);

            while ($produit = mysqli_fetch_row($result)) {

                echo '<div class="produit">';

                $imagePath = "img/" . $produit[4];
                if ($produit[4] != '' && file_exists($imagePath)) {
                    echo '<img src="' . htmlspecialchars($imagePath) . '" alt="' . htmlspecialchars($produit[1]) . '">';
                } else {
                    echo '<div style="height: 150px; background-color: #eee;">Pas d\'image</div>';
                }

                echo '<h3>' . htmlspecialchars($produit[1]) . '</h3>';
                echo '<p><strong>' . htmlspecialchars($produit[3]) . ' €</strong></p>';
                echo '<a href="page_produit.php?id=' . $produit[0] . '">Voir le produit</a>';

                echo '</div>';
            }
            ?>
        </div>
    </main>
    <?php include("footer.php"); ?>
</body>
</html>
