<?php
require_once("config/connect_db.php"); // Connexion à la base
include("header.php"); // Inclusion de l'en-tête

// Requête pour récupérer tous les produits
$sql = "SELECT * FROM produits";
$resultat = mysqli_query($conn, $sql);

// Vérifie si la requête a réussi
if (!$resultat) {
    echo "Erreur MySQL : " . mysqli_error($conn);
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Produits</title>
    <style>
        table {
            border-collapse: collapse;
            width: 90%;
            margin: 30px auto;
            background-color: #f9f9f9;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 12px;
            text-align: center;
        }
        th {
            background-color: #eee;
        }
        img {
            max-width: 100px;
        }
        a {
            text-decoration: none;
            color: blue;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <h1 style="text-align:center;">Liste des Produits</h1>

    <table>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Description</th>
            <th>Prix (€)</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>

        <?php
        while ($produit = mysqli_fetch_row($resultat)) {
            echo "<tr>";
            echo "<td>" . $produit[0] . "</td>";
            echo "<td>" . htmlspecialchars($produit[1]) . "</td>";
            echo "<td>" . htmlspecialchars($produit[2]) . "</td>";
            echo "<td>" . htmlspecialchars($produit[3]) . "</td>";

            $imagePath = "img/" . $produit[4];
            if ($produit[4] != '' && file_exists($imagePath)) {
                echo "<td><img src='$imagePath' alt='image produit'></td>";
            } else {
                echo "<td><em>Pas d'image</em></td>";
            }

            echo "<td>
                    <a href='page_produit.php?id=" . $produit[0] . "'>Voir</a> |
                    <a href='modifier.php?id=" . $produit[0] . "'>Modifier</a> |
                    <a href='supprimer.php?id=" . $produit[0] . "' onclick=\"return confirm('Confirmer la suppression ?');\">Supprimer</a>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
    <p><br><a href="ajouter.php">➕ Ajouter un nouveau produit</a></p>
    <?php include("footer.php"); ?>
</body>
</html>

